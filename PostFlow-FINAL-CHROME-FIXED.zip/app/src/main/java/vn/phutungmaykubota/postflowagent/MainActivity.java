package vn.phutungmaykubota.postflowagent;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "postflow_agent_final";
    private static final String DEFAULT_SERVER =
            "https://postflow.phutungmaykubota.vn";

    private EditText serverUrl;
    private EditText agentToken;
    private TextView statusText;
    private TextView deviceText;
    private TextView chromeText;
    private TextView errorText;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable statusPoller = new Runnable() {
        @Override
        public void run() {
            updateLocalStatus();
            sendHeartbeat();
            handler.postDelayed(this, 15000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            setContentView(R.layout.activity_main);

            serverUrl = findViewById(R.id.serverUrl);
            agentToken = findViewById(R.id.agentToken);
            statusText = findViewById(R.id.statusText);
            deviceText = findViewById(R.id.deviceText);
            chromeText = findViewById(R.id.chromeText);
            errorText = findViewById(R.id.errorText);

            final SharedPreferences prefs =
                    getSharedPreferences(PREFS, MODE_PRIVATE);

            serverUrl.setText(prefs.getString("server", DEFAULT_SERVER));
            agentToken.setText(prefs.getString("agent_token", ""));
            deviceText.setText("Device ID: " + getAgentDeviceId());

            Button save = findViewById(R.id.saveButton);
            Button access = findViewById(R.id.accessibilityButton);
            Button test = findViewById(R.id.testButton);

            save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = serverUrl.getText().toString().trim();
                    String token = agentToken.getText().toString().trim();

                    while (url.endsWith("/")) {
                        url = url.substring(0, url.length() - 1);
                    }

                    prefs.edit()
                            .putString("server", url)
                            .putString("agent_token", token)
                            .apply();

                    setStatus(token.isEmpty()
                            ? "Đã lưu. Chưa ghép Agent với panel."
                            : "Đã lưu mã ghép nối.");
                    clearError();
                    sendHeartbeat();
                }
            });

            access.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        startActivity(
                                new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                        );
                    } catch (Exception e) {
                        showError(e);
                    }
                }
            });

            test.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    updateLocalStatus();
                    testConnection();
                    sendHeartbeat();
                }
            });

            updateLocalStatus();
        } catch (Throwable t) {
            showFatalError(t);
        }
    }

    private String getAgentDeviceId() {
        SharedPreferences prefs =
                getSharedPreferences(PREFS, MODE_PRIVATE);

        String id = prefs.getString("device_id", null);

        if (id == null || id.trim().isEmpty()) {
            id = UUID.randomUUID().toString();
            prefs.edit().putString("device_id", id).apply();
        }

        return id;
    }

    private void testConnection() {
        if (serverUrl == null) return;

        final String base = serverUrl.getText().toString().trim();
        if (base.isEmpty()) {
            setStatus("Chưa nhập PostFlow Server URL.");
            return;
        }

        setStatus("Đang kiểm tra kết nối...");
        clearError();

        executor.execute(new Runnable() {
            @Override
            public void run() {
                int code = -1;
                String error = null;
                java.net.HttpURLConnection connection = null;

                try {
                    java.net.URL url = new java.net.URL(base);
                    connection =
                            (java.net.HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    connection.setInstanceFollowRedirects(true);
                    code = connection.getResponseCode();
                } catch (Exception e) {
                    error = e.getClass().getSimpleName() + ": " + e.getMessage();
                } finally {
                    if (connection != null) connection.disconnect();
                }

                final int result = code;
                final String finalError = error;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (result >= 200 && result < 400) {
                            setStatus("PostFlow HTTP: " + result);
                        } else if (finalError != null) {
                            setStatus("Kết nối lỗi. HTTP: " + result);
                            setError(finalError);
                        } else {
                            setStatus("Kết nối lỗi. HTTP: " + result);
                        }
                        updateLocalStatus();
                    }
                });
            }
        });
    }

    private void sendHeartbeat() {
        if (executor.isShutdown()) return;

        executor.execute(new Runnable() {
            @Override
            public void run() {
                AgentSync.Result r = AgentSync.heartbeat(MainActivity.this);

                if (r.ok) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            setStatus("Agent: ĐÃ ĐỒNG BỘ PANEL");
                            clearError();
                            updateLocalStatus();
                        }
                    });
                } else if (r.code == 401 || r.code == 403 || r.code == 409) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            setStatus("Agent: MÃ GHÉP NỐI KHÔNG HỢP LỆ");
                            setError(r.message);
                        }
                    });
                }
            }
        });
    }

    private void updateLocalStatus() {
        if (statusText == null || chromeText == null) return;

        boolean enabled = PostFlowAccessibilityService.isRunning;

        if (!enabled) {
            statusText.setText("Agent: Accessibility CHƯA BẬT");
        } else if (AgentSync.token(this).trim().isEmpty()) {
            statusText.setText("Agent: ĐANG BẬT • CHƯA GHÉP PANEL");
        }

        boolean chrome = PostFlowAccessibilityService.isChromeActive();
        boolean facebook = PostFlowAccessibilityService.isFacebookActive();
        String url = PostFlowAccessibilityService.lastUrl == null
                ? "" : PostFlowAccessibilityService.lastUrl;

        if (chrome) {
            if (facebook) {
                chromeText.setText(
                        "Chrome: đang hoạt động\nFacebook: ĐÃ PHÁT HIỆN\nURL: " + url
                );
            } else if (!url.isEmpty()) {
                chromeText.setText(
                        "Chrome: đang hoạt động\nURL: " + url
                );
            } else {
                chromeText.setText(
                        "Chrome: đang hoạt động\nFacebook: chưa phát hiện"
                );
            }
        } else if (PostFlowAccessibilityService.facebookDetected) {
            chromeText.setText("Facebook: đang hoạt động");
        } else {
            // Never show Launcher/IME package as the Chrome status.
            chromeText.setText("Chrome/Facebook: chưa phát hiện");
        }
    }

    private void setStatus(final String text) {
        if (statusText == null) return;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (statusText != null) statusText.setText(text);
            }
        });
    }

    private void setError(final String text) {
        if (errorText != null) {
            errorText.setText(text == null ? "" : text);
        }
    }

    private void clearError() {
        if (errorText != null) errorText.setText("");
    }

    private void showError(final Throwable t) {
        final String text =
                t.getClass().getSimpleName() + ": " + t.getMessage();
        setError(text);
    }

    private void showFatalError(Throwable t) {
        try {
            setContentView(R.layout.activity_main);
            errorText = findViewById(R.id.errorText);

            if (errorText != null) {
                errorText.setText(
                        "Agent không thể khởi tạo:\n" +
                        t.getClass().getSimpleName() + "\n" +
                        String.valueOf(t.getMessage())
                );
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateLocalStatus();
        handler.removeCallbacks(statusPoller);
        handler.post(statusPoller);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(statusPoller);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(statusPoller);
        executor.shutdownNow();
        super.onDestroy();
    }
}
