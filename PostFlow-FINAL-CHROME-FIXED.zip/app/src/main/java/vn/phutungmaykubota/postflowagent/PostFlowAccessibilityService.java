package vn.phutungmaykubota.postflowagent;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * PostFlow Agent - Chrome/Facebook detector.
 *
 * Important:
 * - Only Chrome/Facebook application packages are accepted as foreground state.
 * - IME/launcher/other app events NEVER overwrite Chrome state.
 * - For Chrome, only the omnibox URL node is inspected.
 */
public class PostFlowAccessibilityService extends AccessibilityService {

    public static volatile boolean isRunning = false;
    public static volatile String lastPackage = "";
    public static volatile String lastUrl = "";
    public static volatile boolean facebookDetected = false;
    public static volatile long lastEventTime = 0L;
    public static volatile long lastChromeTime = 0L;

    private static final String CHROME = "com.android.chrome";
    private static final String FACEBOOK = "com.facebook.katana";
    private static final String FACEBOOK_LITE = "com.facebook.lite";

    private static final long STATE_TIMEOUT_MS = 30000L;

    private static final Pattern FACEBOOK_URL = Pattern.compile(
            "(?i)^(?:https?://)?(?:www\\.)?(?:[a-z0-9-]+\\.)*facebook\\.com(?:[/:?#].*)?$"
    );

    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable poller = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;
            refreshChromeFromActiveWindow();
            expireStaleState();
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable heartbeat = new Runnable() {
        @Override
        public void run() {
            if (!isRunning) return;

            new Thread(new Runnable() {
                @Override
                public void run() {
                    AgentSync.heartbeat(PostFlowAccessibilityService.this);
                }
            }, "PostFlowHeartbeat").start();

            handler.postDelayed(this, 15000);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();

        isRunning = true;
        lastEventTime = System.currentTimeMillis();

        handler.removeCallbacks(poller);
        handler.removeCallbacks(heartbeat);

        handler.post(poller);
        handler.post(heartbeat);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !isRunning) return;

        lastEventTime = System.currentTimeMillis();

        String pkg = event.getPackageName() == null
                ? ""
                : event.getPackageName().toString();

        /*
         * CRITICAL:
         * Do NOT call a generic foreground-window detector first.
         * Android may report Launcher/IME/LabanKey while Chrome remains
         * the visible browser. Such events must never erase Chrome state.
         */
        if (CHROME.equals(pkg)) {
            markChrome(event);
            return;
        }

        if (FACEBOOK.equals(pkg) || FACEBOOK_LITE.equals(pkg)) {
            lastPackage = pkg;
            facebookDetected = true;
            lastUrl = "";
            lastChromeTime = System.currentTimeMillis();
            return;
        }

        /*
         * Ignore Launcher, keyboard, System UI and every unrelated package.
         * This is the key fix for the previous "com.android.launcher3" bug.
         */
        expireStaleState();
    }

    private void markChrome(AccessibilityEvent event) {
        long now = System.currentTimeMillis();

        lastPackage = CHROME;
        lastChromeTime = now;

        AccessibilityNodeInfo source = null;

        try {
            source = event.getSource();

            if (source != null) {
                String url = findChromeUrlBar(source);

                if (!url.isEmpty()) {
                    updateChromeUrl(url);
                    return;
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (source != null) {
                try {
                    source.recycle();
                } catch (Throwable ignored) {
                }
            }
        }

        /*
         * Event is definitely from Chrome even if Chrome temporarily hides
         * or rebuilds the URL bar. Keep Chrome alive and keep the last known
         * Facebook URL instead of replacing it with Launcher/IME.
         */
        facebookDetected = facebookDetected && isFacebookUrl(lastUrl);
    }

    /**
     * Poll Chrome's actual active application window.
     * This is only used to refresh Chrome state, never to replace it with
     * Launcher/IME/another app.
     */
    private void refreshChromeFromActiveWindow() {
        if (!isRunning) return;

        AccessibilityNodeInfo root = null;

        try {
            root = getRootInActiveWindow();

            if (root == null) return;

            CharSequence p = root.getPackageName();
            String pkg = p == null ? "" : p.toString();

            if (!CHROME.equals(pkg)) {
                return;
            }

            lastPackage = CHROME;
            lastChromeTime = System.currentTimeMillis();

            String url = findChromeUrlBar(root);

            if (!url.isEmpty()) {
                updateChromeUrl(url);
            }
        } catch (Throwable ignored) {
        } finally {
            if (root != null) {
                try {
                    root.recycle();
                } catch (Throwable ignored) {
                }
            }
        }

        /*
         * Some Chrome versions expose the root through a window instead.
         * Only inspect windows whose ROOT package is Chrome.
         */
        if (lastPackage.equals(CHROME)) {
            refreshChromeFromWindows();
        }
    }

    private void refreshChromeFromWindows() {
        List<AccessibilityWindowInfo> windows;

        try {
            windows = getWindows();
        } catch (Throwable ignored) {
            return;
        }

        if (windows == null) return;

        for (AccessibilityWindowInfo window : windows) {
            if (window == null) continue;
            if (window.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;

            AccessibilityNodeInfo root = null;

            try {
                root = window.getRoot();
                if (root == null) continue;

                CharSequence p = root.getPackageName();
                String pkg = p == null ? "" : p.toString();

                if (!CHROME.equals(pkg)) continue;

                lastPackage = CHROME;
                lastChromeTime = System.currentTimeMillis();

                String url = findChromeUrlBar(root);
                if (!url.isEmpty()) {
                    updateChromeUrl(url);
                    return;
                }
            } catch (Throwable ignored) {
            } finally {
                if (root != null) {
                    try {
                        root.recycle();
                    } catch (Throwable ignored) {
                    }
                }
            }
        }
    }

    /**
     * Only search for Chrome's omnibox resource id.
     * We never recursively read arbitrary Facebook page text.
     */
    private String findChromeUrlBar(AccessibilityNodeInfo node) {
        if (node == null) return "";

        try {
            CharSequence id = node.getViewIdResourceName();

            if (id != null) {
                String s = id.toString().toLowerCase(Locale.US);

                if (s.contains("url_bar") || s.endsWith(":id/url_bar")) {
                    String value = nodeValue(node);

                    if (looksLikeUrlOrFacebook(value)) {
                        return value;
                    }
                }
            }

            int count = node.getChildCount();

            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child = null;

                try {
                    child = node.getChild(i);

                    if (child != null) {
                        String found = findChromeUrlBar(child);

                        if (!found.isEmpty()) {
                            return found;
                        }
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (child != null) {
                        try {
                            child.recycle();
                        } catch (Throwable ignored) {
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }

        return "";
    }

    private String nodeValue(AccessibilityNodeInfo node) {
        CharSequence text = node.getText();

        if (text != null && text.length() > 0) {
            return text.toString().trim();
        }

        CharSequence description = node.getContentDescription();

        if (description != null && description.length() > 0) {
            return description.toString().trim();
        }

        return "";
    }

    private boolean looksLikeUrlOrFacebook(String value) {
        if (value == null) return false;

        String s = value.trim();

        if (s.isEmpty()) return false;

        return s.matches("(?i)^https?://.*")
                || s.matches("(?i)^(?:www\\.)?(?:[a-z0-9-]+\\.)*facebook\\.com(?:/.*)?$")
                || s.matches("(?i)^facebook\\.com(?:/.*)?$");
    }

    private void updateChromeUrl(String value) {
        String url = normalizeUrl(value);

        if (url.isEmpty()) return;

        lastPackage = CHROME;
        lastUrl = url;
        lastChromeTime = System.currentTimeMillis();
        facebookDetected = isFacebookUrl(url);
    }

    private String normalizeUrl(String value) {
        if (value == null) return "";

        String s = value.trim();

        if (s.isEmpty()) return "";

        if (!s.matches("(?i)^https?://.*")) {
            if (s.matches("(?i)^(?:www\\.)?(?:[a-z0-9-]+\\.)*facebook\\.com(?:/.*)?$")) {
                return "https://" + s;
            }
        }

        return s;
    }

    private boolean isFacebookUrl(String value) {
        if (value == null) return false;

        String s = value.trim();

        if (s.isEmpty()) return false;

        return FACEBOOK_URL.matcher(s).matches();
    }

    private void expireStaleState() {
        long now = System.currentTimeMillis();

        if (CHROME.equals(lastPackage)
                && lastChromeTime > 0
                && now - lastChromeTime > STATE_TIMEOUT_MS) {

            lastPackage = "";
            lastUrl = "";
            facebookDetected = false;
        }
    }

    public static boolean isChromeActive() {
        long now = System.currentTimeMillis();

        return CHROME.equals(lastPackage)
                && lastChromeTime > 0
                && now - lastChromeTime <= STATE_TIMEOUT_MS;
    }

    public static boolean isFacebookActive() {
        return isChromeActive() && facebookDetected;
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(poller);
        handler.removeCallbacks(heartbeat);

        isRunning = false;
        lastPackage = "";
        lastUrl = "";
        facebookDetected = false;
        lastChromeTime = 0L;

        super.onDestroy();
    }
}
